#' Does nothing but print out a chosen integer
#' @export
version_check <- function(){
  print(16)
}